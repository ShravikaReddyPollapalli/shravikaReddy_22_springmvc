package com.capgemini.springmvc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.springmvc.bean.EmployeeInfoBean;
import com.capgemini.springmvc.service.EmployeeService;
@Controller
public class EmployeeController {
	@Autowired
	private EmployeeService employeeService;
	
	@GetMapping("/searchEmployeeForm")
	public String displaySearchEmployeeForm() {
		
		return "searchEmployee";
	}
	@GetMapping("/searchEmp")
	public String searchEmployee(@RequestParam(name="empId") int empIdVal,ModelMap modelMap) {
		EmployeeInfoBean bean=employeeService.getEmployee(empIdVal);
		if(bean!=null) {
		modelMap.addAttribute("empInfo",bean);
	}else {
		modelMap.addAttribute("errMsg","Employee Details not found");
		
	}
		return "searchEmployee";
	}
	
	@GetMapping("/addEmployeeForm")
	public String displayAddEmployee() {
		
		return "addEmployee";
	}

	@PostMapping("/addEmp")
	public String addEmployee(EmployeeInfoBean bean,ModelMap modelMap) {
		
		boolean isAdded=employeeService.addEmployee(bean);
		
		if(isAdded) {
			modelMap.addAttribute("msg", "Employee Added succesfully");
			
		}
		else {
			modelMap.addAttribute("errMsg", "Unable to Add Employee Details");
		}
		return "addEmployee";
	}
	@GetMapping("/updateEmployeeForm")
	public String displayUpdateEmployeeForm() {

		return "updateEmployee";

	}
	
	@GetMapping("/updateEmp")
	public String updateEmployee(EmployeeInfoBean employeeBean,ModelMap modelMap) {
		
		boolean  isUpdated = employeeService.updateEmployee(employeeBean);
		
		if(isUpdated) {
			modelMap.addAttribute("empInfo","Employee updated sucessfull");
		}else {
			modelMap.addAttribute("errMsg", "unable to update emppoyeee data");

		}

		return "updateEmployee";
		
	}
	
	
	@GetMapping("/deleteEmployeeForm")
	public String diplayDeleteEmployeeForm() {

		return "deleteEmployee";

	}
	
	@GetMapping("/deleteEmp")
	public String  deleteEmployee(@RequestParam(name="empId") int empIdVal,ModelMap modelMap) {
		
		boolean isAdded= employeeService.deleteEmployee(empIdVal);
		if(isAdded) {
			modelMap.addAttribute("empInfo","Employee deleted sucessfull");
		}else {
			modelMap.addAttribute("errMsg", "unable to delete emppoyeee data");

		}
		return "deleteEmployee";
		
	}


	@GetMapping("/allEmployeesDetails")
	public String dispalyAllEmployee() {
		
		return "getAllEmployees";
	}

	@GetMapping("/allEmpDet")
	public String allEmployee(EmployeeInfoBean bean,ModelMap modelMap) {
			
		List<EmployeeInfoBean> bean1=employeeService.getAllEmployees();
	
		if(bean1!=null && !bean1.isEmpty()) {
			modelMap.addAttribute("msg", bean1);
		}
		else {
			modelMap.addAttribute("errMsg", "EmployeeDetails are not available");
		}
		return "getAllEmployees";
	
	}
}
