package com.capgemini.springmvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.springmvc.bean.EmployeeInfoBean;
import com.capgemini.springmvc.dao.EmployeeDAO;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	EmployeeDAO employeeDAO;

	@Override
	public EmployeeInfoBean getEmployee(int empId) {
		if (empId > 0) {
			return employeeDAO.getEmployee(empId);
		}
		return null;
	}

	@Override
	public boolean addEmployee(EmployeeInfoBean employeeInfoBean) {
		if (employeeInfoBean != null) {
			return employeeDAO.addEmployee(employeeInfoBean);
		}
		return false;
	}

	@Override
	public boolean updateEmployee(EmployeeInfoBean employeeInfoBean) {

		return employeeDAO.updateEmployee(employeeInfoBean);
	}

	@Override
	public boolean deleteEmployee(int empId) {

		return employeeDAO.deleteEmployee(empId);
	}

	@Override
	public List<EmployeeInfoBean> getAllEmployees() {

		return employeeDAO.getAllEmployees();
	}

	@Override
	public EmployeeInfoBean authenticate(int empId, String password) {
		if (empId < 1 || password == null || password.trim().isEmpty()) {
			return null;

		}
		return employeeDAO.authenticate(empId, password);
	}

}
