package com.capgemini.springmvc.bean;

import lombok.Data;

@Data
public class EmployeeInfoBean {
	 int empId;
     String empName;
     int age;
     double salary;
     String designation;
     String password;
}
